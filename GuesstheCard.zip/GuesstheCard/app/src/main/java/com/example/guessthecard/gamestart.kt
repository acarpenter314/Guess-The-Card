package com.example.guessthecard

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.RadioButton
import android.widget.TextView
import androidx.core.app.ActivityCompat.recreate
import kotlinx.android.synthetic.main.activity_finish.*
import kotlinx.android.synthetic.main.activity_gamestart.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.view.*
import kotlinx.android.synthetic.main.activity_settings.*

val suit = arrayOf("diamonds","hearts","clubs","spades")
var dealerSuit=""
val number = arrayOf("ace","two","three","four","five","six","seven","eight","nine","ten")
var dealerNum=""
var userguessSuit = ""
var userguessNum = ""
var win = 0
var loss = 0

class gamestart : AppCompatActivity() {

    fun ButtonClicked(view: View) {

                if (view is RadioButton) {

            val checked = view.isChecked

            when (view.getId()) {
                R.id.diamonds ->
                    if (checked) {
                        userguessSuit = "diamonds"
                    }
                R.id.hearts ->
                    if (checked) {
                        userguessSuit = "hearts"
                    }
                R.id.clubs ->
                    if (checked) {
                        userguessSuit = "clubs"
                    }
                R.id.spades ->
                    if (checked) {
                        userguessSuit = "spades"
                    }
                R.id.ace->
                    if (checked) {
                        userguessNum = "ace"
                    }
                R.id.two ->
                    if (checked) {
                        userguessNum = "two"
                    }
                R.id.three ->
                    if (checked) {
                        userguessNum = "three"
                    }
                R.id.four ->
                    if (checked) {
                        userguessNum = "four"
                    }
                R.id.five ->
                    if (checked) {
                        userguessNum = "five"
                    }
                R.id.six ->
                    if (checked) {
                        userguessNum = "six"
                    }
                R.id.seven ->
                    if (checked) {
                        userguessNum = "seven"
                    }
                R.id.eight ->
                    if (checked) {
                        userguessNum = "eight"
                    }
                R.id.nine ->
                    if (checked) {
                        userguessNum = "nine"
                    }
                R.id.ten ->
                    if (checked) {
                        userguessNum = "ten"
                    }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gamestart)
        val levelDiff=intent.getStringExtra("difficult")
        dealerSuit = suit.random()
        dealerNum = number.random()

       if (levelDiff.equals("Easy")) {
           suitGroup.setVisibility(View.VISIBLE)
           numberGroup1.setVisibility(View.INVISIBLE)

           revealBtn.setOnClickListener {
               val intent = Intent(this, finish::class.java)
               intent.putExtra("difficult",levelDiff)
               startActivity(intent)
           }
       }
           if (levelDiff.equals("Medium")) {
            suitGroup.setVisibility(View.INVISIBLE)
            numberGroup1.setVisibility(View.VISIBLE)


               revealBtn.setOnClickListener {
                   val intent = Intent(this, finish::class.java)
                   intent.putExtra("difficult",levelDiff)
                   startActivity(intent)
               }
        }
        if (levelDiff.equals("Hard")) {
            suitGroup.setVisibility(View.VISIBLE)
            numberGroup1.setVisibility(View.VISIBLE)


            revealBtn.setOnClickListener {
                val intent = Intent(this, finish::class.java)
                intent.putExtra("difficult",levelDiff)
                startActivity(intent)
            }
        }
        mainBtn.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}