package com.example.guessthecard

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_finish.*
import kotlinx.android.synthetic.main.activity_gamestart.*
import kotlinx.android.synthetic.main.activity_finish.winloss
import kotlinx.android.synthetic.main.activity_main.*

class finish : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_finish)
        winloss.text = ""
        val diff=intent.getStringExtra("difficult")

        if (diff.equals("Easy")) {
            revealCard.text = dealerSuit.capitalize()
            userReveal.text = userguessSuit.capitalize()
            if (dealerSuit == userguessSuit) {
                win++
                winloss.text = "Win"
            }

            else {
                loss++
                winloss.text = "Loss"
            }
            wins.text = win.toString()
            losses.text = loss.toString()
        }

        if (diff.equals("Medium")) {
            revealCard.text = dealerNum.capitalize()
            userReveal.text = userguessNum.capitalize()
            if (dealerNum == userguessNum) {
                win++
                winloss.text = "Win"
            }

            else {
                loss++
                winloss.text = "Loss"
             }

            wins.text = win.toString()
            losses.text = loss.toString()
        }

        if (diff.equals("Hard")) {
            revealCard.text = dealerNum.capitalize() + " of " + dealerSuit.capitalize()
            userReveal.text = userguessNum.capitalize() + " of " + userguessSuit.capitalize()
            if (dealerNum == userguessNum && dealerSuit == userguessSuit) {
                win++
                winloss.text = "Win"
            }

            else {
                loss++
                winloss.text = "Loss"
            }

            wins.text = win.toString()
            losses.text = loss.toString()
        }

        yesBtn.setOnClickListener {
           val intent = Intent(this, gamestart::class.java)
            intent.putExtra("difficult",diff)
          startActivity(intent)
        }

        noBtn.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}