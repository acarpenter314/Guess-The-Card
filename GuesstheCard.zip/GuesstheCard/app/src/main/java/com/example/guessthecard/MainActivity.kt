package com.example.guessthecard

import android.content.Intent
import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.SeekBar
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_settings.*

lateinit var slider: SeekBar
lateinit var value: TextView


val difficulty= arrayListOf<String>("Easy","Medium","Hard")
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        value=myDifficulty
        slider=mySeekBar

        slider.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                value.text=difficulty[progress]

            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
            }
        })

        settingsBtn.setOnClickListener {
            val intent = Intent(this, settings::class.java)
            startActivity(intent)
        }
        helpBtn.setOnClickListener {
            val intent = Intent(this, help::class.java)
            startActivity(intent)
        }
        startBtn.setOnClickListener {
            val intent = Intent(this@MainActivity, gamestart::class.java)
            val difficult = value.text.toString()
            intent.putExtra("difficult",difficult)
            startActivity(intent)
        }


    }

}